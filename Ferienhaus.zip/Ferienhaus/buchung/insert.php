<?php
require dirname(__DIR__) . '/connect/connect.php';
require dirname(__DIR__) . '/style/insert-style.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $gast_id = trim($_POST['gast_id']);
    $ferienhaus_id = trim($_POST['ferienhaus_id']);
    $ankunft = trim($_POST['ankunft']);
    $abfahrt = trim($_POST['abfahrt']);

    if (!empty($gast_id) && !empty($ferienhaus_id) && !empty($ankunft) && !empty($abfahrt)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO buchung (gast_id, ferienhaus_id, ankunft, abfahrt) 
                                   VALUES (:gast_id, :ferienhaus_id, :ankunft, :abfahrt)");
            $stmt->bindValue(':gast_id', $gast_id);
            $stmt->bindValue(':ferienhaus_id', $ferienhaus_id);
            $stmt->bindValue(':ankunft', $ankunft);
            $stmt->bindValue(':abfahrt', $abfahrt);
            $stmt->execute();

            header('Location: buchung.php?success=1');
            exit;
        } catch (PDOException $e) {
            die("Fehler beim Einfügen: " . $e->getMessage());
        }
    } else {
        echo "<p style='color:red; text-align:center;'>Bitte alle Felder ausfüllen!</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Neue Buchung hinzufügen</title>
    <style>
        body {
            background-color: #f2f2f2;
            font-family: Arial, sans-serif;
        }
        h1 {
            color: #006400;
        }
        form {
            background-color: #ffffe0;
            padding: 20px;
            border-radius: 10px;
            width: 50%;
            margin: auto;
        }
        label {
            display: block;
            margin: 10px 0 5px;
        }
        input {
            width: 100%;
            padding: 10px;
            margin: 5px 0 20px;
            border: 1px solid #006400;
        }
        button {
            background-color: #006400;
            color: white;
            padding: 10px;
            width: 100%;
            cursor: pointer;
        }
        button:hover {
            background-color: #004d00;
        }
        .back-button {
            display: inline-block;
            margin-top: 20px;
            color: white;
            background-color: #ffcc00;
            padding: 10px;
            text-decoration: none;
            border-radius: 5px;
        }
        .back-button:hover {
            background-color: #e6b800;
        }
    </style>
</head>
<body>

<h1>Neue Buchung hinzufügen</h1>
<form method="POST">
    <label for="gast_id">Gast-ID:</label>
    <input type="number" name="gast_id" required>

    <label for="ferienhaus_id">Ferienhaus-ID:</label>
    <input type="number" name="ferienhaus_id" required>

    <label for="ankunft">Ankunft:</label>
    <input type="date" name="ankunft" required>

    <label for="abfahrt">Abfahrt:</label>
    <input type="date" name="abfahrt" required>

    <button type="submit">Buchung speichern</button>
</form>

<a href="buchung.php" class="back-button">Zurück</a>

</body>
</html>
