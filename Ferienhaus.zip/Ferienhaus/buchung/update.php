<?php
require dirname(__DIR__) . '/connect/connect.php';
require dirname(__DIR__) . '/style/update-style.php';

$id = $_GET['id'] ?? null;
if (!$id) die('Keine ID angegeben.');

$stmt = $pdo->prepare('SELECT * FROM buchung WHERE id = :id');
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$stmt->execute();
$buchung = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$buchung) die('Buchung nicht gefunden.');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $gast_id = $_POST['gast_id'];
    $ferienhaus_id = $_POST['ferienhaus_id'];
    $ankunft = $_POST['ankunft'];
    $abfahrt = $_POST['abfahrt'];

    if ($gast_id && $ferienhaus_id && $ankunft && $abfahrt) {
        $stmt = $pdo->prepare("
            UPDATE buchung SET
            gast_id = :gast_id,
            ferienhaus_id = :ferienhaus_id,
            ankunft = :ankunft,
            abfahrt = :abfahrt
            WHERE id = :id
        ");
        $stmt->bindValue(':gast_id', $gast_id);
        $stmt->bindValue(':ferienhaus_id', $ferienhaus_id);
        $stmt->bindValue(':ankunft', $ankunft);
        $stmt->bindValue(':abfahrt', $abfahrt);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        header('Location: buchung.php?updated=1');
        exit;
    } else {
        echo "<p style='color:red;'>Bitte alle Felder ausfüllen!</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buchung bearbeiten</title>
    <style>
        body {
            background-color: #f2f2f2;
            font-family: Arial, sans-serif;
        }
        h1 {
            color: #006400;
        }
        form {
            background-color: #ffffe0;
            padding: 20px;
            border-radius: 10px;
            width: 50%;
            margin: auto;
        }
        label {
            display: block;
            margin: 10px 0 5px;
        }
        input {
            width: 100%;
            padding: 10px;
            margin: 5px 0 20px;
            border: 1px solid #006400;
        }
        button {
            background-color: #006400;
            color: white;
            padding: 10px;
            width: 100%;
            cursor: pointer;
        }
        button:hover {
            background-color: #004d00;
        }
        .back-button {
            display: inline-block;
            margin-top: 20px;
            color: white;
            background-color: #ffcc00;
            padding: 10px;
            text-decoration: none;
            border-radius: 5px;
        }
        .back-button:hover {
            background-color: #e6b800;
        }
    </style>
</head>
<body>

<h1>Buchung bearbeiten</h1>
<form method="POST">
    <label for="gast_id">Gast-ID:</label>
    <input type="number" name="gast_id" value="<?= htmlspecialchars($buchung['gast_id']) ?>" required>

    <label for="ferienhaus_id">Ferienhaus-ID:</label>
    <input type="number" name="ferienhaus_id" value="<?= htmlspecialchars($buchung['ferienhaus_id']) ?>" required>

    <label for="ankunft">Ankunft:</label>
    <input type="date" name="ankunft" value="<?= htmlspecialchars($buchung['ankunft']) ?>" required>

    <label for="abfahrt">Abfahrt:</label>
    <input type="date" name="abfahrt" value="<?= htmlspecialchars($buchung['abfahrt']) ?>" required>

    <button type="submit">Aktualisieren</button>
</form>

<a href="buchung.php" class="back-button">Zurück</a>

</body>
</html>
