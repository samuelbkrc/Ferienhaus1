<?php
require dirname(__DIR__) . '/connect/connect.php';
require dirname(__DIR__) . '/style/buchung-style.php';

$stmt = $pdo->prepare('SELECT * FROM buchung ORDER BY id');
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buchungsübersicht</title>
    <style>
        body {
            background-color: #f2f2f2; /* Heller Hintergrund */
            font-family: Arial, sans-serif;
        }
        h1 {
            color: #006400; /* Grüner Titel */
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #ffffe0; /* Gelber Hintergrund für Tabelle */
        }
        th, td {
            padding: 10px;
            text-align: center;
            border: 1px solid #006400; /* Grüne Grenze */
        }
        th {
            background-color: #006400; /* Dunkelgrüner Header */
            color: white;
        }
        .action-btn {
            padding: 5px 10px;
            color: white;
            background-color: #ffcc00; /* Gelber Hintergrund für Buttons */
            border: none;
            cursor: pointer;
        }
        .action-btn:hover {
            background-color: #e6b800; /* Dunklerer Gelbton */
        }
        .add-btn-container a {
            color: white;
            background-color: #006400;
            padding: 10px;
            text-decoration: none;
            border-radius: 5px;
        }
        .add-btn-container a:hover {
            background-color: #004d00;
        }
    </style>
</head>
<body>

<h1>Buchungen Übersicht</h1>
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Gast ID</th>
            <th>Ferienhaus ID</th>
            <th>Ankunft</th>
            <th>Abfahrt</th>
            <th>Erstellt am</th>
            <th>Update</th>
            <th>Delete</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($results as $result): ?>
            <tr>
                <td><?= htmlspecialchars($result['id']) ?></td>
                <td><?= htmlspecialchars($result['gast_id']) ?></td>
                <td><?= htmlspecialchars($result['ferienhaus_id']) ?></td>
                <td><?= htmlspecialchars($result['ankunft']) ?></td>
                <td><?= htmlspecialchars($result['abfahrt']) ?></td>
                <td><?= htmlspecialchars($result['erstellt_am']) ?></td>
                <td><a href="update.php?id=<?= $result['id'] ?>" class="action-btn btn-update">Update</a></td>
                <td><a href="delete.php?deleteID=<?= $result['id'] ?>" class="action-btn btn-delete" onclick="return confirm('Wirklich löschen?');">Delete</a></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<div class="add-btn-container">
    <a href="insert.php" class="btn">Neue Buchung hinzufügen</a>
</div>

</body>
</html>
