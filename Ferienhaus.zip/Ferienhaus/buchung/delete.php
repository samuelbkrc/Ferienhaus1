<?php
require dirname(__DIR__) . '/connect/connect.php';

if (isset($_GET['deleteID'])) {
    $id = (int) $_GET['deleteID'];

    try {
        $stmt = $pdo->prepare('DELETE FROM buchung WHERE id = :id');
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        header("Location: buchung.php?deleted=1");
        exit;
    } catch (PDOException $e) {
        die("Fehler beim Löschen: " . $e->getMessage());
    }
} else {
    header("Location: buchung.php?error=1");
    exit;
}
?>
